<?php
$lang["posts"] = "Posts";
$lang["posts_no_members"] = "No members found.";
$lang["posts_manage"] = "Manage";
$lang["posts_delete"] = "Delete";
$lang["posts_no_found"] = "No posts found.";
$lang["posts_new_member"] = "New member";
$lang["posts_my_team"] = "My Team";
$lang["posts_scheduled_posts"] = "Scheduled Posts";
$lang["posts_last_rss_posts"] = "Last RSS Posts";
$lang["posts_statistics"] = "Statistics";
$lang["posts_in_the_last_30_days"] = "Published posts in the last 30 days";