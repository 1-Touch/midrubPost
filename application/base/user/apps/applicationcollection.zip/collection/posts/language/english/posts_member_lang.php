<?php
$lang["posts"] = "Posts";
$lang["posts_allow"] = "Allow Posts";
$lang["posts_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Posts.";