<?php
$lang["user_posts"] = "User Posts";
$lang["user_posts_description"] = "<p>User Posts allows you to read posts. Tis permissions allows to get up to 100 posts per page.</p>";
$lang["user_posts_allow"] = "Read your posts.";
$lang["user_social_accounts"] = "User Social Accounts";
$lang["user_social_accounts_description"] = "<p>User Social Accounts allows .</p>";
$lang["user_social_accounts_allow"] = "Access and manage your social accounts.";