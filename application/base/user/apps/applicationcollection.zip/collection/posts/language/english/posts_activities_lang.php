<?php
$lang["has_published_comment"] = "has published a comment on ";
$lang["has_published_post"] = "has published a post";
$lang["has_drafted_post"] = "has drafted a post";
$lang["has_scheduled_post"] = "has scheduled a post to be published after ";
$lang["has_published_drafted_scheduled_post"] = "has scheduled, drafted or published a post";