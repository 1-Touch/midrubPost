<?php
$lang["stream"] = "Stream";
$lang["stream_allow"] = "Allow Stream";
$lang["stream_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Stream.";