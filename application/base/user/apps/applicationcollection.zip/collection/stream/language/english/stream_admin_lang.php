<?php
$lang["stream"] = "Stream";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled"] = "If is enabled users will see the Plans page";
$lang["if_is_enabled_plan"] = "If is enabled the Stream app will be available for this plan";
$lang["stream_tabs_limit"] = "Stream Tabs";
$lang["stream_tabs_limit_description"] = "Enter the number of Tabs which user can create";
