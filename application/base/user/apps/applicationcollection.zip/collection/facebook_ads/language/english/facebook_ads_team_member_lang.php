<?php
$lang["facebook_advertising"] = "Advertising";
$lang["facebook_advertising_allow"] = "Allow Facebook Advertising";
$lang["facebook_advertising_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Facebook Advertising.";