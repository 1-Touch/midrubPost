<?php
$lang["facebook_ads"] = "Facebook Ads";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled"] = "If is enabled users will see the Plans page";
$lang["if_is_enabled_plan"] = "If is enabled the Stream app will be available for this plan";
$lang["fb_ads_enable_posts_boosting"] = "Enable Posts Boosting";
$lang["fb_ads_enable_posts_boosting_description"] = "If is enabled users will be able to boost posts from Posts app.";