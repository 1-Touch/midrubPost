<?php
$lang["chatbot_activity_stats"] = "Bot Activity Per Day";
$lang["chatbot_totally_stats"] = "Bot Activity Totally";
$lang["chatbot_subscribers"] = "Last Subscribers";
$lang["chatbot_chatbot_history"] = "Chatbot History";
$lang["chatbot_commenter_history"] = "Commenter History";
$lang["chatbot_no_subscribers_found"] = "No subscribers found.";
$lang["chatbot_details"] = "Details";
$lang["chatbot_no_conversations_found"] = "No conversations found.";