<?php
$lang["chatbot"] = "Chatbot";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled_chatbot"] = "You will be able to see it in the Plans page";
$lang["if_is_enabled_chatbot_plan"] = "If is enabled the chatbot app will be available for this plan";
$lang["app_token"] = "App Token";
$lang["app_token_description"] = "Invent an App Token which you will use here and in Facebook Webhooks.";
$lang["number_allowed_replies"] = "Bot Replies";
$lang["number_allowed_replies_description"] = "Enter the number of bot's replies per month.";
$lang["activity_widget"] = "Activity Widget";
$lang["activity_widget_description"] = "If is enabled the Activity Widget will be displayed.";
$lang["history_widget"] = "History Widget";
$lang["history_widget_description"] = "If is enabled the History Widget will be displayed.";