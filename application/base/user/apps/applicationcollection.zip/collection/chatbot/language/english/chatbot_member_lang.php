<?php
$lang["chatbot"] = "Facebook Chatbot";
$lang["chatbot_allow"] = "Allow Facebook Chatbot";
$lang["chatbot_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Facebook Chatbot.";