<?php
$lang["dashboard"] = "Dashboard";
$lang["dashboard_allow"] = "Allow Dashboard";
$lang["dashboard_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Dashboard.";