<?php
$lang["dashboard"] = "Dashboard";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled"] = "If is enabled users will see the dashboard page.";
$lang["enable_app_default_widgets"] = "Enable Default Widgets";
$lang["if_is_enabled_default_widgets"] = "If is enabled users will see the default system widgets.";
$lang["left_side_defaul_widgets"] = "Put default widgets at the left side of first widget";
$lang["if_is_enabled_default_side"] = "By default the 4 default widgets are the at the top of the dashboard page.";
$lang["teams"] = "Teams";
$lang["if_is_enabled_plan"] = "If is enabled the Dashboard app will be available for this plan";