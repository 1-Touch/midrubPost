<?php
$lang["upgrade"] = "Upgrade";
$lang["teams"] = "Teams";
$lang["all_teams_members"] = "All teams members";
$lang["posts"] = "Posts";
$lang["in_this_month"] = "In this month";
$lang["storage"] = "Storage";
$lang["total_available_storage"] = "Total available storage";
$lang["dashboard"] = "Dashboard";
$lang["your_subscription_has_expired"] = "Your subscription plan has expired. No worries! You can easily renew now.";
$lang["your_subscription_expires"] = "Your subscription plan expires soon. No worries! You can easily renew it.";
$lang["our_plans"] = "Our Plans";