<?php
$lang["storage"] = "Storage";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled_storage"] = "You will be able to see it in the Plans page";
$lang["if_is_enabled_storage_plan"] = "If is enabled the Storage app will be available for this plan";
$lang["enable_url_download"] = "Enable Images Url Download";
$lang["enable_url_download_description"] = "If is enabled users will be able to download images from url.";
