<?php
$lang["storage"] = "Storage";
$lang["storage_allow"] = "Allow Storage";
$lang["storage_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Storage.";