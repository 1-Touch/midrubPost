<?php
$lang["planner"] = "Planner";
$lang["planner_allow"] = "Planner";
$lang["planner_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Planner.";
$lang["planner_display_media_categories"] = "Display Media Categories";
$lang["planner_display_media_categories_description"] = "If is enabled you will be able to select a media category for each plannification";