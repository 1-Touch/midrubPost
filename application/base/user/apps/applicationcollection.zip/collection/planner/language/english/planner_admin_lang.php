<?php
$lang["planner"] = "Planner";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled"] = "If is enabled will be displayed in the Plans page";
$lang["if_is_enabled_plan"] = "If is enabled the Planner app will be available for this plan";
$lang["number_allowed_plannifications"] = "Number of planifications";
$lang["number_allowed_plannifications_description"] = "Please add a limit because someone could abuse.";
$lang["enable_planner_faq"] = "Enable Planner's Faq";
$lang["if_is_enable_planner_faq"] = "If is enabled the Faq instructions will be displayed in the Planner's Page.";
