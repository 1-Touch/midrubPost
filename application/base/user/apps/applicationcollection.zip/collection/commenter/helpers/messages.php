<?php
/**
 * Messages Helpers
 * 
 * PHP Version 7.3
 *
 * This file contains the class Messages
 * with methods to process the messages data
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Commenter\Helpers;

// Constats
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Messages class provides the methods to process the messages data
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
*/
class Messages {
    
    /**
     * Class variables
     *
     * @since 0.0.8.0
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.0
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
        // Load the FB Commenter Replies Model
        $this->CI->load->ext_model( MIDRUB_BASE_USER_APPS_COMMENTER . 'models/', 'Fb_commenter_replies_model', 'fb_commenter_replies_model' );
        
    }

    //-----------------------------------------------------
    // Main class's methods
    //-----------------------------------------------------
    
    /**
     * The public method save_message saves a message
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function save_message() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('keywords', 'Keywords', 'trim|required');
            $this->CI->form_validation->set_rules('response_type', 'Response Type', 'trim');
            $this->CI->form_validation->set_rules('message', 'Message', 'trim');
            $this->CI->form_validation->set_rules('group', 'Group', 'trim');

            // Get data
            $keywords = $this->CI->input->post('keywords', TRUE);
            $response_type = $this->CI->input->post('response_type', TRUE);
            $message = $this->CI->input->post('message', TRUE);
            $group = $this->CI->input->post('group', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare no category found message
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_keywords_too_short')
                );

                // Display response
                echo json_encode($data);
                exit();
                
            } else {

                // Try to create the message's parameters
                $message_args = array(
                    'user_id' => $this->CI->user_id,
                    'body' => $keywords,
                    'accuracy' => 100,
                    'created' => time()
                );

                // Save Message's parameters by using the Base's Model
                $message_id = $this->CI->base_model->insert('chatbot_replies', $message_args);

                // Verify if the message was saved
                if ( $message_id ) {

                    // Try to create the message's response
                    $response = array(
                        'reply_id' => $message_id,
                        'type' => $response_type
                    );

                    // Verify what kind of response has the message's response
                    if ( $response_type === '1' ) {

                        $response['body'] = $message;

                    } else if ( $response_type === '2' ) {

                        $response['group_id'] = $group;

                    }

                    // Save Message's response by using the Base's Model
                    $response_id = $this->CI->base_model->insert('chatbot_replies_response', $response);

                    // Verify if the response was saved
                    if ( $response_id ) {

                        // Prepare the success message
                        $data = array(
                            'success' => TRUE,
                            'message' => $this->CI->lang->line('commenter_message_was_saved')
                        );

                        // Display error message
                        echo json_encode($data);

                    } else {

                        // Prepare the success message
                        $data = array(
                            'success' => TRUE,
                            'message' => $this->CI->lang->line('commenter_message_was_saved_without_response')
                        );

                        // Display success message
                        echo json_encode($data);

                    }
                    
                } else {

                    // Prepare the error message
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('commenter_message_was_not_saved')
                    );

                    // Display error message
                    echo json_encode($data);

                }

                exit();
                
            }
            
        }

        // Prepare the error message
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('commenter_error_occurred')
        );

        // Display error message
        echo json_encode($data);
        
    }

    /**
     * The public method update_message updates a message
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function update_message() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('message_id', 'Message ID', 'trim');
            $this->CI->form_validation->set_rules('keywords', 'Keywords', 'trim|required');
            $this->CI->form_validation->set_rules('accuracy', 'Accuracy', 'trim');
            $this->CI->form_validation->set_rules('response_type', 'Response Type', 'trim');
            $this->CI->form_validation->set_rules('message', 'Message', 'trim');
            $this->CI->form_validation->set_rules('group', 'Group', 'trim');
            $this->CI->form_validation->set_rules('categories', 'Categories', 'trim');

            // Get data
            $message_id = $this->CI->input->post('message_id', TRUE);
            $keywords = $this->CI->input->post('keywords', TRUE);
            $accuracy = $this->CI->input->post('accuracy', TRUE);
            $response_type = $this->CI->input->post('response_type', TRUE);
            $message = $this->CI->input->post('message', TRUE);
            $group = $this->CI->input->post('group', TRUE);
            $categories = $this->CI->input->post('categories', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare no category found message
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_keywords_too_short')
                );

                // Display response
                echo json_encode($data);
                exit();
                
            } else {

                // Verify if the Message ID is numeric
                if ( is_numeric($message_id) ) {

                    // Use the base model for a simply sql query
                    $get_message = $this->CI->base_model->get_data_where(
                        'chatbot_replies',
                        'reply_id',
                        array(
                            'reply_id' => $message_id,
                            'user_id' => $this->CI->user_id
                        )
                    );

                    // Verify if the message is of the current user
                    if ( $get_message ) {

                        // Prepare the message's keywords
                        $message_keywords = array(
                            'body' => $keywords
                        );

                        // Verify if accuracy exists
                        if ( is_numeric($accuracy) && ( $accuracy > 9 && $accuracy < 101 ) ) {

                            // Set accuracy
                            $message_keywords['accuracy'] = $accuracy;

                        } else {

                            // Set accuracy
                            $message_keywords['accuracy'] = 100;
                            
                        }

                        // Try to update the message
                        $this->CI->base_model->update_ceil('chatbot_replies', array('reply_id' => $message_id), $message_keywords);

                        // Use the base model for a simply sql query
                        $get_updated_message = $this->CI->base_model->get_data_where(
                            'chatbot_replies',
                            '*',
                            array(
                                'reply_id' => $message_id,
                                'user_id' => $this->CI->user_id
                            )
                        );

                        // Very if keywords were updated
                        if ( ($get_updated_message[0]['body'] === $message_keywords['body']) && ($get_updated_message[0]['accuracy'] === $message_keywords['accuracy']) ) {

                            // Delete the Message's responses
                            $this->CI->base_model->delete('chatbot_replies_response', array('reply_id' => $message_id));

                            // Verify which kind of response has the message
                            switch ( $response_type ) {

                                case '1':

                                    // Try to create the message's response
                                    $response = array(
                                        'reply_id' => $message_id,
                                        'body' => $message,
                                        'type' => $response_type
                                    );

                                    // Save Message's response by using the Base's Model
                                    $response_id = $this->CI->base_model->insert('chatbot_replies_response', $response);

                                    // If message's response wasn't saved notify the user
                                    if ( !$response_id ) {

                                        // Prepare the error message
                                        $data = array(
                                            'success' => FALSE,
                                            'message' => $this->CI->lang->line('commenter_message_was_updated_successfully_without_response')
                                        );

                                        // Display error message
                                        echo json_encode($data);
                                        exit();

                                    }

                                    break;

                                case '2':

                                    // Verify if group exists
                                    if ( $group ) {

                                        // Try to create the message's response
                                        $response = array(
                                            'reply_id' => $message_id,
                                            'group_id' => $group,
                                            'type' => $response_type
                                        );

                                        // Save Message's response by using the Base's Model
                                        $response_id = $this->CI->base_model->insert('chatbot_replies_response', $response);

                                        // If message's response wasn't saved notify the user
                                        if ( !$response_id ) {

                                            // Prepare the error message
                                            $data = array(
                                                'success' => FALSE,
                                                'message' => $this->CI->lang->line('commenter_message_was_updated_successfully_without_response')
                                            );

                                            // Display error message
                                            echo json_encode($data);
                                            exit();

                                        }

                                    }

                                    break;

                            }

                            // Delete the message's categories
                            $this->CI->base_model->delete('chatbot_replies_categories', array('reply_id' => $message_id));

                            // Verify if categories exists
                            if ( $categories ) {

                                // Count categories
                                $count = 0;

                                // List all categories
                                foreach ($categories as $category_id) {

                                    // Use the base model to verify if user is the owner of the category
                                    $get_category = $this->CI->base_model->get_data_where(
                                        'chatbot_categories',
                                        '*',
                                        array(
                                            'category_id' => $category_id,
                                            'user_id' => $this->CI->user_id
                                        )
                                    );

                                    // Verify if the category and user exists
                                    if ( $get_category ) {

                                        // Prepare the Category
                                        $category = array(
                                            'reply_id' => $message_id,
                                            'category_id' => $category_id
                                        );

                                        // Save the Category
                                        if ($this->CI->base_model->insert('chatbot_replies_categories', $category)) {
                                            $count++;
                                        }

                                    }

                                }

                                // Verify if all categories were saved
                                if (count($categories) > $count) {

                                    // Prepare the error message
                                    $data = array(
                                        'success' => FALSE,
                                        'message' => $this->CI->lang->line('commenter_message_was_updated_successfully_without_categories')
                                    );

                                    // Display error message
                                    echo json_encode($data);
                                    exit();
                                    
                                }

                            }

                            // Prepare the success message
                            $data = array(
                                'success' => TRUE,
                                'message' => $this->CI->lang->line('commenter_message_was_updated_successfully')
                            );

                            // Display success message
                            echo json_encode($data);

                        } else {

                            // Prepare the error message
                            $data = array(
                                'success' => FALSE,
                                'message' => $this->CI->lang->line('commenter_message_was_not_updated_successfully')
                            );

                            // Display error message
                            echo json_encode($data);

                        }

                    } else {

                        // Prepare the error message
                        $data = array(
                            'success' => FALSE,
                            'message' => $this->CI->lang->line('commenter_message_id_missing')
                        );

                        // Display error message
                        echo json_encode($data);

                    }
                    
                } else {

                    // Prepare the error message
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('commenter_message_id_missing')
                    );

                    // Display error message
                    echo json_encode($data);

                }

                exit();
                
            }
            
        }

        // Prepare the error message
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('commenter_error_occurred')
        );

        // Display error message
        echo json_encode($data);
        
    }

    /**
     * The public method load_messages loads messages
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function load_messages() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('key', 'Key', 'trim');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $key = $this->CI->input->post('key', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_no_messages_found')
                );

                // Display the false response
                echo json_encode($data);
                
            } else {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Set the limit
                $limit = 10;
                $page--;

                // Use the base model for a simply sql query
                $get_messages = $this->CI->base_model->get_data_where(
                    'chatbot_replies',
                    'reply_id, body',
                    array(
                        'user_id' => $this->CI->user_id
                    ),
                    array(),
                    array('body' => $this->CI->db->escape_like_str($key)),
                    array(),
                    array(
                        'order' => array('reply_id', 'desc'),
                        'start' => ($page * $limit),
                        'limit' => $limit
                    )
                );

                // Verify if messages exists
                if ( $get_messages ) {

                    // Get total number of messages with base model
                    $total = $this->CI->base_model->get_data_where(
                        'chatbot_replies',
                        'COUNT(reply_id) AS total',
                        array(
                            'user_id' => $this->CI->user_id
                        ),
                        array(),
                        array('body' => $this->CI->db->escape_like_str($key)),
                        array(),
                        array()
                    );

                    // Prepare the response
                    $data = array(
                        'success' => TRUE,
                        'messages' => $get_messages,
                        'total' => $total[0]['total'],
                        'page' => ($page + 1)
                    );

                    // Display the response
                    echo json_encode($data);

                } else {

                    // Prepare the false response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('commenter_no_messages_found')
                    );

                    // Display the false response
                    echo json_encode($data);

                }
                
            }
            
        }
        
    }

    /**
     * The public method check_for_messages verifies if user has messages
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function check_for_messages() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Use the base model for a simply sql query
            $get_messages = $this->CI->base_model->get_data_where(
                'chatbot_replies',
                'reply_id, body',
                array(
                    'user_id' => $this->CI->user_id
                )
            );

            // Verify if messages exists
            if ($get_messages) {

                // Prepare the response
                $data = array(
                    'success' => TRUE
                );

                // Display the response
                echo json_encode($data);

            } else {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_no_messages_found')
                );

                // Display the false response
                echo json_encode($data);

            }
            
        }
        
    }

    /**
     * The public method delete_messages deletes messages
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function delete_messages() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('messages', 'Messages', 'trim');
            
            // Get data
            $messages = $this->CI->input->post('messages');

            // Verify if request is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Default count
                $count = 0;

                // List all messages
                foreach ( $messages as $message ) {

                    // Verify if the message id is numeric
                    if (is_numeric($message[1])) {

                        // Try to delete message
                        if ( $this->CI->base_model->delete('chatbot_replies', array('reply_id' => $message[1], 'user_id' => $this->CI->user_id)) ) {

                            // Delete the message response
                            $this->CI->base_model->delete('chatbot_replies_response', array('reply_id' => $message[1]) );

                            // Increase count
                            $count++;

                        }

                    }

                }

                if ( $count ) {

                    $data = array(
                        'success' => TRUE,
                        'message' => $count . $this->CI->lang->line('commenter_messages_were_deleted')
                    );

                    echo json_encode($data);

                } else {

                    $data = array(
                        'success' => FALSE,
                        'message' => '0' . $this->CI->lang->line('commenter_messages_were_deleted')
                    );

                    echo json_encode($data);

                }
                
                exit();
                
            }
            
        }
        
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('commenter_error_occurred')
        );

        echo json_encode($data);
        
    }

    /**
     * The public method messages_for_graph loads messages for graph
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function messages_for_graph() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('page_id', 'Page ID', 'trim');

            // Get data
            $page_id = $this->CI->input->post('page_id', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Loads messages by popularity
                $messages = $this->CI->fb_commenter_replies_model->replies_for_graph($this->CI->user_id, $page_id);

                // Verify if messages exists
                if ( $messages ) {

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'messages' => $messages,
                        'words' => array(
                            'number_bot_messages' => $this->CI->lang->line('commenter_number_bot_messages')
                        )
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'words' => array(
                'number_bot_messages' => $this->CI->lang->line('commenter_number_bot_messages')
            )
        );

        // Display the false response
        echo json_encode($data);
        
    }

    /**
     * The public method dashboard_replies_for_graph loads messages for graph
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function dashboard_messages_for_graph() {

        // Loads messages by popularity
        $messages = $this->CI->fb_commenter_replies_model->replies_for_graph($this->CI->user_id);

        // Verify if messages exists
        if ($messages) {

            // Prepare the success response
            $data = array(
                'success' => TRUE,
                'messages' => $messages,
                'words' => array(
                    'number_bot_messages' => $this->CI->lang->line('commenter_number_bot_messages')
                )
            );

            // Display the success response
            echo json_encode($data);
            
        } else {

            // Prepare the false response
            $data = array(
                'success' => FALSE,
                'words' => array(
                    'number_bot_messages' => $this->CI->lang->line('commenter_number_bot_messages')
                )
            );

            // Display the false response
            echo json_encode($data);

        }
        
    }

    /**
     * The public method message_activity_graph loads activities for a message
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function message_activity_graph() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('message_id', 'Message ID', 'trim|numeric|required');

            // Get data
            $message_id = $this->CI->input->post('message_id', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Loads message's activity for graph
                $activities = $this->CI->fb_commenter_replies_model->reply_activity_graph($this->CI->user_id, $message_id);

                // Verify if activity exists
                if ( $activities ) {

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'activities' => $activities,
                        'words' => array(
                            'number_bot_messages' => $this->CI->lang->line('commenter_number_bot_messages')
                        )
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'words' => array(
                'number_bot_messages' => $this->CI->lang->line('commenter_number_bot_messages')
            )
        );

        // Display the false response
        echo json_encode($data);
        
    }
    
    /**
     * The public method messages_by_popularity loads messages by popularity
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function messages_by_popularity() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Add form validation
            $this->CI->form_validation->set_rules('page_id', 'Page ID', 'trim');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $page_id = $this->CI->input->post('page_id', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Decrease the page
                $page--;

                // Loads messages by popularity
                $messages = $this->CI->fb_commenter_replies_model->replies_by_popularity($this->CI->user_id, $page_id, $page);

                // Verify if messages exists
                if ( $messages ) {

                    // Calculate total number of messages
                    $total_messages = $this->CI->fb_commenter_replies_model->replies_by_popularity($this->CI->user_id, $page_id);

                    // Prepare the success response
                    $data = array(
                        'success' => TRUE,
                        'messages' => $messages,
                        'total' => count($total_messages),
                        'page' => ($page + 1)
                    );

                    // Display the success response
                    echo json_encode($data);
                    exit();

                }

            }

        }

        // Prepare the false response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('commenter_no_messages_found')
        );

        // Display the false response
        echo json_encode($data);
        
    }
    
}

/* End of file messages.php */