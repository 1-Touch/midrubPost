<?php
/**
 * Keywords Helpers
 * 
 * PHP Version 7.3
 *
 * This file contains the class Keywords
 * with methods to process the keywords data
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Commenter\Helpers;

// Constats
defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Keywords class provides the methods to process the moderation keywords data
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
*/
class Keywords {
    
    /**
     * Class variables
     *
     * @since 0.0.8.0
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.0
     */
    public function __construct() {
        
        // Get codeigniter object instance
        $this->CI =& get_instance();
        
        // Load the FB Commenter Keywords Moderation Model
        $this->CI->load->ext_model( MIDRUB_BASE_USER_APPS_COMMENTER . 'models/', 'Fb_commenter_keywords_moderation_model', 'fb_commenter_keywords_moderation_model' );
        
    }

    //-----------------------------------------------------
    // Main class's methods
    //-----------------------------------------------------
    
    /**
     * The public method save_moderation_keywords saves moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function save_moderation_keywords() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('keywords', 'Keywords', 'trim|required');

            // Get data
            $keywords = $this->CI->input->post('keywords', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare no category found message
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_keywords_too_short')
                );

                // Display response
                echo json_encode($data);
                exit();
                
            } else {

                // Try to create the moderation keywords parameters
                $args = array(
                    'user_id' => $this->CI->user_id,
                    'body' => $keywords,
                    'accuracy' => 100,
                    'created' => time()
                );

                // Save moderation keywords parameters by using the Base's Model
                $last_id = $this->CI->base_model->insert('chatbot_moderation_keywords', $args);

                // Verify if the message was saved
                if ( $last_id ) {

                    // Prepare the success message
                    $data = array(
                        'success' => TRUE,
                        'message' => $this->CI->lang->line('commenter_moderation_keywords_were_saved')
                    );

                    // Display success message
                    echo json_encode($data);
                    
                } else {

                    // Prepare the error message
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('commenter_moderation_keywords_were_not_saved')
                    );

                    // Display error message
                    echo json_encode($data);

                }

                exit();
                
            }
            
        }

        // Prepare the error message
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('commenter_error_occurred')
        );

        // Display error message
        echo json_encode($data);
        
    }

    /**
     * The public method update_moderation_keywords updates moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function update_moderation_keywords() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('keywords_id', 'Keywords ID', 'trim');
            $this->CI->form_validation->set_rules('keywords', 'Keywords', 'trim|required');
            $this->CI->form_validation->set_rules('accuracy', 'Accuracy', 'trim');

            // Get data
            $keywords_id = $this->CI->input->post('keywords_id', TRUE);
            $keywords = $this->CI->input->post('keywords', TRUE);
            $accuracy = $this->CI->input->post('accuracy', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare no category found message
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_keywords_too_short')
                );

                // Display response
                echo json_encode($data);
                exit();
                
            } else {

                // Verify if the Keywords ID is numeric
                if ( is_numeric($keywords_id) ) {

                    // Use the base model for a simply sql query
                    $get_keywords = $this->CI->base_model->get_data_where(
                        'chatbot_moderation_keywords',
                        'keywords_id',
                        array(
                            'keywords_id' => $keywords_id,
                            'user_id' => $this->CI->user_id
                        )
                    );

                    // Verify if the keywords is of the current user
                    if ( $get_keywords ) {

                        // Prepare the keywords's keywords
                        $keywords_body = array(
                            'body' => $keywords
                        );

                        // Verify if accuracy exists
                        if ( is_numeric($accuracy) && ( $accuracy > 9 && $accuracy < 101 ) ) {

                            // Set accuracy
                            $keywords_body['accuracy'] = $accuracy;

                        } else {

                            // Set accuracy
                            $keywords_body['accuracy'] = 100;
                            
                        }

                        // Try to update the moderation keywords
                        $this->CI->base_model->update_ceil('chatbot_moderation_keywords', array('keywords_id' => $keywords_id), $keywords_body);

                        // Use the base model for a simply sql query
                        $get_updated_keywords = $this->CI->base_model->get_data_where(
                            'chatbot_moderation_keywords',
                            '*',
                            array(
                                'keywords_id' => $keywords_id,
                                'user_id' => $this->CI->user_id
                            )
                        );

                        // Very if keywords were updated
                        if ( ($get_updated_keywords[0]['body'] === $keywords_body['body']) && ($get_updated_keywords[0]['accuracy'] === $keywords_body['accuracy']) ) {

                            // Prepare the success message
                            $data = array(
                                'success' => TRUE,
                                'message' => $this->CI->lang->line('commenter_keywords_was_updated_successfully')
                            );

                            // Display success message
                            echo json_encode($data);

                        } else {

                            // Prepare the error message
                            $data = array(
                                'success' => FALSE,
                                'message' => $this->CI->lang->line('commenter_keywords_was_not_updated_successfully')
                            );

                            // Display error message
                            echo json_encode($data);

                        }

                    } else {

                        // Prepare the error message
                        $data = array(
                            'success' => FALSE,
                            'message' => $this->CI->lang->line('commenter_keywords_id_missing')
                        );

                        // Display error message
                        echo json_encode($data);

                    }
                    
                } else {

                    // Prepare the error message
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('commenter_keywords_id_missing')
                    );

                    // Display error message
                    echo json_encode($data);

                }

                exit();
                
            }
            
        }

        // Prepare the error message
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('commenter_error_occurred')
        );

        // Display error message
        echo json_encode($data);
        
    }

    /**
     * The public method load_keywords loads keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function load_keywords() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('key', 'Key', 'trim');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $key = $this->CI->input->post('key', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_no_keywords_found')
                );

                // Display the false response
                echo json_encode($data);
                
            } else {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Set the limit
                $limit = 10;
                $page--;

                // Use the base model for a simply sql query
                $get_keywords = $this->CI->base_model->get_data_where(
                    'chatbot_moderation_keywords',
                    'keywords_id, body',
                    array(
                        'user_id' => $this->CI->user_id
                    ),
                    array(),
                    array('body' => $this->CI->db->escape_like_str($key)),
                    array(),
                    array(
                        'order' => array('keywords_id', 'desc'),
                        'start' => ($page * $limit),
                        'limit' => $limit
                    )
                );

                // Verify if keywords exists
                if ( $get_keywords ) {

                    // Get total number of keywords with base model
                    $total = $this->CI->base_model->get_data_where(
                        'chatbot_moderation_keywords',
                        'COUNT(keywords_id) AS total',
                        array(
                            'user_id' => $this->CI->user_id
                        ),
                        array(),
                        array('body' => $this->CI->db->escape_like_str($key)),
                        array(),
                        array()
                    );

                    // Prepare the response
                    $data = array(
                        'success' => TRUE,
                        'keywords' => $get_keywords,
                        'total' => $total[0]['total'],
                        'page' => ($page + 1)
                    );

                    // Display the response
                    echo json_encode($data);

                } else {

                    // Prepare the false response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('commenter_no_keywords_found')
                    );

                    // Display the false response
                    echo json_encode($data);

                }
                
            }
            
        }
        
    }

    /**
     * The public method check_for_moderation_keywords verifies if user has moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function check_for_moderation_keywords() {

        // Check if data was submitted
        if ($this->CI->input->post()) {

            // Use the base model for a simply sql query
            $get_moderation_keywords = $this->CI->base_model->get_data_where(
                'chatbot_moderation_keywords',
                'keywords_id, body',
                array(
                    'user_id' => $this->CI->user_id
                )
            );

            // Verify if moderation keywords exists
            if ($get_moderation_keywords) {

                // Prepare the response
                $data = array(
                    'success' => TRUE
                );

                // Display the response
                echo json_encode($data);

            } else {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_no_keywords_found')
                );

                // Display the false response
                echo json_encode($data);

            }
            
        }
        
    }

    /**
     * The public method delete_moderation_keywords deletes moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function delete_moderation_keywords() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('keywords', 'Keywords', 'trim');
            
            // Get data
            $keywords = $this->CI->input->post('keywords');

            // Verify if request is correct
            if ( $this->CI->form_validation->run() !== false ) {

                // Default count
                $count = 0;

                // List all keywords
                foreach ( $keywords as $keyword ) {

                    // Verify if the keywords id is numeric
                    if (is_numeric($keyword[1])) {

                        // Try to delete keyword
                        if ( $this->CI->base_model->delete('chatbot_moderation_keywords', array('keywords_id' => $keyword[1], 'user_id' => $this->CI->user_id)) ) {

                            // Delete all moderation keyword's records
                            run_hook(
                                'delete_moderation_keyword',
                                array(
                                    'keywords_id' => $keyword[1]
                                )

                            );

                            // Increase count
                            $count++;

                        }

                    }

                }

                // Verify if at least one keyword were deleted
                if ( $count ) {
                    
                    // Prepare success response
                    $data = array(
                        'success' => TRUE,
                        'message' => $count . $this->CI->lang->line('commenter_moderation_keywords_were_delete')
                    );

                    // Display success response
                    echo json_encode($data);

                } else {

                    // Prepare error response
                    $data = array(
                        'success' => FALSE,
                        'message' => '0' . $this->CI->lang->line('commenter_moderation_keywords_were_not_delete')
                    );

                    // Display error response
                    echo json_encode($data);

                }
                
                exit();
                
            }
            
        }

        // Prepare error response
        $data = array(
            'success' => FALSE,
            'message' => $this->CI->lang->line('commenter_error_occurred')
        );

        // Display error response
        echo json_encode($data);
        
    }

    /**
     * The public method load_moderated_comments loads the moderated comments
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */ 
    public function load_moderated_comments() {

        // Check if data was submitted
        if ($this->CI->input->post()) {
            
            // Add form validation
            $this->CI->form_validation->set_rules('keywords_id', 'Keywords ID', 'trim|integer|numeric');
            $this->CI->form_validation->set_rules('page', 'Page', 'trim');

            // Get data
            $keywords_id = $this->CI->input->post('keywords_id', TRUE);
            $page = $this->CI->input->post('page', TRUE);
            
            // Verify if the submitted data is correct
            if ( $this->CI->form_validation->run() === false ) {

                // Prepare the false response
                $data = array(
                    'success' => FALSE,
                    'message' => $this->CI->lang->line('commenter_no_comments_found')
                );

                // Display the false response
                echo json_encode($data);
                
            } else {

                // If $page is false, set 1
                if (!$page) {
                    $page = 1;
                }

                // Set the limit
                $limit = 10;
                $page--;

                // Use the base model for a simply sql query
                $get_comments = $this->CI->base_model->get_data_where(
                    'chatbot_moderation_history',
                    'chatbot_moderation_history.history_id, chatbot_moderation_history.net_id, chatbot_moderation_history.name, chatbot_moderation_history.question, chatbot_moderation_history.created, networks.secret',
                    array(
                        'chatbot_moderation_history.user_id' => $this->CI->user_id,
                        'chatbot_moderation_history.keywords_id' => $keywords_id
                    ),
                    array(),
                    array(),
                    array(array(
                        'table' => 'networks',
                        'condition' => 'chatbot_moderation_history.page_id=networks.network_id',
                        'join_from' => 'LEFT'
                    )),
                    array(
                        'order' => array('chatbot_moderation_history.history_id', 'desc'),
                        'start' => ($page * $limit),
                        'limit' => $limit
                    )
                );

                // Verify if conversations exists
                if ( $get_comments ) {

                    // Get total number of conversations with base model
                    $total = $this->CI->base_model->get_data_where(
                        'chatbot_moderation_history',
                        'COUNT(chatbot_moderation_history.history_id) AS total',
                        array(
                            'chatbot_moderation_history.user_id' => $this->CI->user_id,
                            'chatbot_moderation_history.keywords_id' => $keywords_id
                        ),
                        array(),
                        array(),
                        array(array(
                            'table' => 'networks',
                            'condition' => 'chatbot_moderation_history.page_id=networks.network_id',
                            'join_from' => 'LEFT'
                        ))
                    );

                    // Create new conversations array
                    $comments = array();

                    // List conversations
                    foreach ( $get_comments as $comment ) {

                        // Sub array
                        $sub_array = array(
                            'history_id' => $comment['history_id'],
                            'name' => $comment['name'],
                            'question' => $comment['question'],
                            'created' => $comment['created']
                        );

                        // Get user's image
                        $image = get(MIDRUB_COMMENTER_FACEBOOK_GRAPH_URL . $comment['net_id'] . '/picture?type=square&access_token=' . $comment['secret']);

                        // Verify if user has image
                        if ($image !== FALSE) {

                            // Set user's image
                            $sub_array['image'] = MIDRUB_COMMENTER_FACEBOOK_GRAPH_URL . $comment['net_id'] . '/picture?type=large&access_token=' . $comment['secret'];

                        } else {

                            // Set default user's image
                            $sub_array['image'] = base_url('assets/img/avatar-placeholder.png');

                        }

                        // Add subscriber to array
                        $comments[] = $sub_array;

                    }

                    // Prepare the response
                    $data = array(
                        'success' => TRUE,
                        'comments' => $comments,
                        'total' => $total[0]['total'],
                        'page' => ($page + 1),
                        'date' => time()
                    );

                    // Display the response
                    echo json_encode($data);

                } else {

                    // Prepare the false response
                    $data = array(
                        'success' => FALSE,
                        'message' => $this->CI->lang->line('commenter_no_comments_found')
                    );

                    // Display the false response
                    echo json_encode($data);

                }
                
            }
            
        }
        
    }

}

/* End of file keywords.php */