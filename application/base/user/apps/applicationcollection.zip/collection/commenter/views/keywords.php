<section class="commenter-page-keywords" data-keywords="<?php echo htmlspecialchars($keywords_id); ?>">
    <div class="row">
        <div class="col-12">
            <div class="theme-box new-message-top">
                <?php echo form_open('user/app/commenter', array('class' => 'save-moderation-keywords-form', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                <div class="row">
                    <div class="col-4 col-lg-8">
                        <textarea class="form-control moderation-keywords" rows="3" placeholder="<?php echo $this->lang->line('commenter_enter_the_keywords'); ?>" required><?php echo htmlspecialchars($keywords); ?></textarea>
                    </div>
                    <div class="col-8 col-lg-4 text-right">
                        <div class="btn-group" role="group">
                            <div class="dropdown show">
                                <button class="btn btn-secondary dropdown-toggle keywords-accuracy" data-id="<?php echo $accuracy; ?>" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo ($accuracy) ? $accuracy . '%' : '<i class="fas fa-percent"></i> ' . $this->lang->line('commenter_accuracy'); ?>
                                </button>

                                <div class="dropdown-menu dropdown-menu-action keywords-accuracy-list" aria-labelledby="dropdownMenuLink">
                                    <a class="dropdown-item" data-id="10" href="#">10%</a>
                                    <a class="dropdown-item" data-id="20" href="#">20%</a>
                                    <a class="dropdown-item" data-id="30" href="#">30%</a>
                                    <a class="dropdown-item" data-id="40" href="#">40%</a>
                                    <a class="dropdown-item" data-id="50" href="#">50%</a>
                                    <a class="dropdown-item" data-id="60" href="#">60%</a>
                                    <a class="dropdown-item" data-id="70" href="#">70%</a>
                                    <a class="dropdown-item" data-id="80" href="#">80%</a>
                                    <a class="dropdown-item" data-id="90" href="#">90%</a>
                                    <a class="dropdown-item" data-id="100" href="#">100%</a>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-secondary theme-background-blue commenter-save-message">
                                <i class="lni-save"></i>
                                <?php echo $this->lang->line('save'); ?>
                            </button>
                        </div>
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>
            <div class="new-message-body clean">
                <div class="row">
                    <div class="col-12 mb-4">
                        <div class="theme-box clean message-response">
                            <div class="row">
                                <div class="col-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3>
                                                <i class="lni-play"></i>
                                                <?php echo $this->lang->line('commenter_actions'); ?>
                                            </h3>
                                        </div>
                                        <div class="panel-body">
                                            <p>
                                                <i class="lni-alarm"></i>
                                                <?php echo $this->lang->line('commenter_actions_delete'); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="theme-box clean hidden-comments">
                            <div class="row">
                                <div class="col-12">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h3>
                                                <i class="icon-bubbles"></i>
                                                <?php echo $this->lang->line('commenter_hidden_comments'); ?>
                                            </h3>
                                        </div>
                                        <div class="panel-body messages-list">
                                            
                                        </div>
                                        <div class="panel-footer">
                                            <nav>
                                                <ul class="pagination" data-type="banned">
                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>