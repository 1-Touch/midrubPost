<a href="<?php echo site_url('user/app/commenter?p=new-suggestions'); ?>" class="btn btn-success commenter-new-suggestions">
    <i class="lni-comment"></i>
    <?php echo $this->lang->line('commenter_new_suggestions_group'); ?>
</a>
<div class="commenter-menu-group">
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter'); ?>" class="nav-link<?php echo (!$this->input->get('p', TRUE))?' active show':''; ?>">
                <i class="lni-comment-reply"></i>
                <?php echo $this->lang->line('commenter_suggestions'); ?>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=private-messages'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'private-messages')?' active show':''; ?>">
                <i class="lni-facebook-messenger"></i>
                <?php echo $this->lang->line('commenter_private_messages'); ?>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=moderate-comments'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'moderate-comments')?' active show':''; ?>">
                <i class="lni-emoji-sad"></i>
                <?php echo $this->lang->line('commenter_moderate_comments'); ?>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=pages'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'pages')?' active show':''; ?>">
                <i class="lni-facebook"></i>
                <?php echo $this->lang->line('commenter_facebook_pages'); ?>
            </a>
        </li>        
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=subscribers'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'subscribers')?' active show':''; ?>">
                <i class="lni-users"></i>
                <?php echo $this->lang->line('commenter_subscribers'); ?>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=history'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'history')?' active show':''; ?>">
                <i class="lni-sort-amount-asc"></i>
                <?php echo $this->lang->line('commenter_history'); ?>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=phone-numbers'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'phone-numbers')?' active show':''; ?>">
                <i class="lni-phone"></i>
                <?php echo $this->lang->line('commenter_phone_numbers'); ?>
            </a>
        </li> 
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=email-addresses'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'email-addresses')?' active show':''; ?>">
                <i class="lni-envelope"></i>
                <?php echo $this->lang->line('commenter_email_addresses'); ?>
            </a>
        </li>   
        <li class="nav-item">
            <a href="<?php echo site_url('user/app/commenter?p=audit-logs'); ?>" class="nav-link<?php echo ($this->input->get('p', TRUE) === 'audit-logs')?' active show':''; ?>">
                <i class="lni-bar-chart"></i>
                <?php echo $this->lang->line('commenter_audit_logs'); ?>
            </a>
        </li>
    </ul>
</div>