<section class="commenter-page" data-up="<?php echo (get_option('upload_limit')) ? get_option('upload_limit'):'6'; ?>">
    <div class="row">
        <div class="col-xl-2 offset-xl-1 theme-box">
            <?php get_the_file(MIDRUB_BASE_USER_APPS_COMMENTER . 'views/menu.php'); ?>
        </div>
        <div class="col-xl-8">
            <div class="commenter-list theme-box">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-8">
                                <i class="lni-emoji-sad"></i>
                                <?php echo $this->lang->line('commenter_moderate_comments'); ?>
                            </div>
                            <div class="col-4">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-primary theme-background-green" data-toggle="modal" data-target="#create-moderation-keywords">
                                        <i class="lni-shortcode"></i>
                                        <?php echo $this->lang->line('commenter_new_keywords'); ?>
                                    </button>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-primary theme-background-green dropdown-toggle" data-toggle="dropdown">
                                            <i class="icon-arrow-down"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="#import-csv" data-toggle="modal">
                                                <i class="lni-exit-down"></i>
                                                <?php echo $this->lang->line('commenter_import_csv'); ?>
                                            </a>
                                            <a class="dropdown-item" href="#export-csv" data-toggle="modal">
                                                <i class="lni-upload"></i>
                                                <?php echo $this->lang->line('commenter_export_csv'); ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-12">
                                <?php echo form_open('user/app/commenter', array('class' => 'search-keywords', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <i class="icon-magnifier"></i>
                                    </div>
                                    <input type="text" class="form-control keywords-key" placeholder="<?php echo $this->lang->line('commenter_search_moderation_keywords'); ?>">
                                    <div class="input-group-append">
                                        <button type="button" class="btn input-group-text cancel-keywords-search">
                                            <i class="icon-close"></i>
                                        </button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="keywords-management">
                                    <div class="checkbox-option-select">
                                        <input id="all-keywords-select" name="all-keywords-select" type="checkbox">
                                        <label for="all-keywords-select"></label>
                                    </div>
                                    <button type="button" class="btn btn-sm btn-primary theme-background-white delete-keywords">
                                        <i class="icon-trash"></i>
                                        <?php echo $this->lang->line('commenter_delete'); ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <ul class="keywords-list">
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <nav>
                            <ul class="pagination" data-type="keywords">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Create New message -->
<div class="modal fade" id="create-moderation-keywords" tabindex="-1" role="dialog" aria-boostledby="create-moderation-keywords" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <?php echo $this->lang->line('commenter_new_keywords_list'); ?>
                </h2>
                <button type="button" class="close" data-dismiss="modal" aria-boost="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open('user/app/commenter', array('class' => 'commenter-create-keywords', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend><?php echo $this->lang->line('commenter_keywords'); ?></legend>
                            <div class="form-group">
                                <textarea class="form-control keywords-list" rows="3" placeholder="<?php echo $this->lang->line('commenter_enter_the_moderation_keywords'); ?>" required></textarea>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend><?php echo $this->lang->line('commenter_actions'); ?></legend>
                            <p>
                                <i class="lni-alarm"></i>
                                <?php echo $this->lang->line('commenter_actions_delete'); ?>
                            </p>
                        </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-right">
                        <fieldset>
                            <button type="submit" class="btn btn-primary">
                                <i class="lni-save"></i>
                                <?php echo $this->lang->line('save'); ?>
                            </button>
                        </fieldset>
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<!-- Import CSV -->
<div class="modal fade" id="import-csv" tabindex="-1" role="dialog" aria-boostledby="import-csv" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <?php echo $this->lang->line('commenter_import_csv'); ?>
                </h2>
                <button type="button" class="close" data-dismiss="modal" aria-boost="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open_multipart('user/app/commenter', array('class' => 'upcsv', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend>
                                <?php echo $this->lang->line('commenter_upload'); ?>
                            </legend>
                            <div class="form-group">
                                <p>
                                    <i class="lni-alarm"></i>
                                    <?php echo $this->lang->line('commenter_import_keywords_csv_instructions'); ?>
                                </p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-secondary theme-background-blue select-csv-file">
                                    <i class="lni-exit-down"></i>
                                    <?php echo $this->lang->line('commenter_select_csv'); ?>
                                </button>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <input type="file" name="csvfile[]" id="csvfile" accept=".csv">
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<!-- Export CSV -->
<div class="modal fade" id="export-csv" tabindex="-1" role="dialog" aria-boostledby="export-csv" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <?php echo $this->lang->line('commenter_export_csv'); ?>
                </h2>
                <button type="button" class="close" data-dismiss="modal" aria-boost="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <fieldset>
                            <legend>
                                <?php echo $this->lang->line('commenter_download'); ?>
                            </legend>
                            <div class="form-group">
                                <p>
                                    <i class="lni-alarm"></i>
                                    <?php echo $this->lang->line('commenter_export_keywords_csv_instructions'); ?>
                                </p>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-secondary theme-background-blue download-csv-file">
                                    <i class="lni-upload"></i>
                                    <?php echo $this->lang->line('commenter_download_keywords_csv'); ?>
                                </button>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Word list for JS !-->
<script language="javascript">
    var words = {
        please_enter_text_message: '<?php echo $this->lang->line('commenter_please_enter_text_message'); ?>',
        please_select_suggestion_group: '<?php echo $this->lang->line('commenter_please_select_suggestion_group'); ?>',
        please_select_at_least_moderation_keyword: '<?php echo $this->lang->line('commenter_please_select_at_least_moderation_keyword'); ?>',
        file_too_large: '<?php echo $this->lang->line('commenter_file_too_large'); ?>',
    };
</script>