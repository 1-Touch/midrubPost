<section class="commenter-page">
    <div class="row">
        <div class="col-xl-2 offset-xl-1 theme-box">
            <?php get_the_file(MIDRUB_BASE_USER_APPS_COMMENTER . 'views/menu.php'); ?>
        </div>
        <div class="col-xl-3 mb-4">
            <div class="commenter-list theme-box">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-12">
                                <i class="lni-facebook"></i>
                                <?php echo $this->lang->line('commenter_facebook_pages'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-12">
                                <?php echo form_open('user/app/commenter', array('class' => 'search-pages', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <i class="icon-magnifier"></i>
                                    </div>
                                    <input type="text" class="form-control search-for-pages" placeholder="<?php echo $this->lang->line('commenter_search_facebook_pages'); ?>">
                                    <div class="input-group-append">
                                        <button type="button" class="btn input-group-text cancel-pages-search">
                                            <i class="icon-close"></i>
                                        </button>
                                        <button type="button" class="pages-manager" data-toggle="modal" data-target="#accounts-manager-popup">
                                            <i class="icon-user-follow"></i>
                                        </button>
                                    </div>
                                </div>
                                <?php echo form_close(); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <ul class="list-pages">
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <nav>
                            <ul class="pagination" data-type="pages">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-5">
            <?php echo form_open('user/app/commenter', array('class' => 'save-page-configuration', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
            <div class="error-connect-facebook-page theme-box">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-12">
                                <i class="lni-cross-circle"></i>
                                <?php echo $this->lang->line('commenter_error_occurred'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <p>
                        </p>
                    </div>
                </div>
            </div>        
            <div class="connect-facebook-page theme-box">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-12">
                                <i class="lni-trowel"></i>
                                <?php echo $this->lang->line('commenter_connect_facebook_page'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <p>
                            <i class="lni-alarm"></i>
                            <?php echo $this->lang->line('commenter_connect_facebook_page_instructions'); ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="connect-to-bot theme-box">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-12">
                                <i class="lni-check-box"></i>
                                <?php echo $this->lang->line('commenter_connect_to_bot'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <p>
                            <i class="lni-alarm"></i>
                            <?php echo $this->lang->line('commenter_connect_to_bot_instructions'); ?>
                        </p>
                        <button class="btn btn-link connect-to-bot-btn theme-background-green text-white" type="button">
                            <?php echo $this->lang->line('commenter_connect_to_bot_btn'); ?>
                        </button>
                        <button class="btn btn-link disconnect-from-bot-btn theme-background-red text-white" type="button">
                            <?php echo $this->lang->line('commenter_disconnect_from_bot_btn'); ?>
                        </button>
                    </div>
                </div>
            </div>
            <div class="categories-list theme-box">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-12">
                                <i class="lni-comment"></i>
                                <?php echo $this->lang->line('commenter_categories'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-12">
                                <p>
                                    <i class="lni-alarm"></i>
                                    <?php echo $this->lang->line('commenter_facebook_categories'); ?>
                                </p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 all-categories-list">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</section>

<!-- Save Button -->
<div class="settings-save-changes row">
    <div class="col-8">
        <p>
            <i class="icon-bell"></i>
            <?php echo $this->lang->line('commenter_you_have_unsaved_changes'); ?>
        </p>
    </div>
    <div class="col-4 text-right">
        <button type="button" class="btn btn-default">
            <i class="far fa-save"></i>
            <?php echo $this->lang->line('commenter_save_changes'); ?>
        </button>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="accounts-manager-popup" tabindex="-1" role="dialog" aria-labelledby="accounts-manager-popup" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <i class="lni-facebook"></i>
                    <?php echo $this->lang->line('commenter_connect_pages'); ?>
                </h2>
                <button type="button" class="close" data-dismiss="modal" aria-boost="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8">
                        <fieldset>
                            <legend>
                                <?php echo $this->lang->line('commenter_facebook_pages'); ?>
                            </legend>
                            <div class="row">
                                <div class="col-12">
                                    <?php echo form_open('user/app/commenter', array('class' => 'search-all-facebook-pages', 'data-csrf' => $this->security->get_csrf_token_name())); ?>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <i class="icon-magnifier"></i>
                                        </div>
                                        <input type="text" class="form-control search-for-pages" placeholder="<?php echo $this->lang->line('commenter_search_facebook_pages'); ?>">
                                        <div class="input-group-append">
                                            <button type="button" class="btn input-group-text cancel-pages-search">
                                                <i class="icon-close"></i>
                                            </button>
                                            <button type="button" class="pages-manager connect-new-facebook-page">
                                                <i class="fab fa-facebook"></i>
                                                <?php echo $this->lang->line('commenter_connect_pages_btn'); ?>
                                            </button>
                                        </div>
                                    </div>
                                    <?php echo form_close(); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <ul class="accounts-manager-accounts-list">
                                    </ul>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                    <div class="col-md-4">
                        <fieldset>
                            <legend>
                                <?php echo $this->lang->line('commenter_instructions'); ?>
                            </legend>
                            <div class="row">
                                <div class="col-12">
                                    <?php echo $this->lang->line('commenter_connect_instructions'); ?>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Word list for JS !-->
<script language="javascript">
    var words = {
        please_enter_text_reply: '<?php echo $this->lang->line('commenter_please_enter_text_reply'); ?>',
        please_select_suggestion_group: '<?php echo $this->lang->line('commenter_please_select_suggestion_group'); ?>',
        please_select_at_least_reply: '<?php echo $this->lang->line('commenter_please_select_at_least_reply'); ?>',
    };
</script>