<?php

/**
 * Ajax Controller
 *
 * This file processes the app's ajax calls
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Commenter\Controllers;

// Constants
defined('BASEPATH') or exit('No direct script access allowed');

// Define the namespaces to use
use MidrubBase\User\Apps\Collection\Commenter\Helpers as MidrubBaseUserAppsCollectionCommenterHelpers;

/*
 * Ajax class processes the app's ajax calls
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
 */

class Ajax
{

    /**
     * Class variables
     *
     * @since 0.0.8.0
     */
    protected $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.0
     */
    public function __construct() {

        // Get codeigniter object instance
        $this->CI = &get_instance();

        // Load language
        $this->CI->lang->load( 'commenter_user', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_COMMENTER );

    }

    /**
     * The public method save_suggestions saves the suggestions group
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function save_suggestions() {

        // Saves a suggestions group
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Suggestions)->save_suggestions();

    }

    /**
     * The public method load_suggestions loads the group with suggestions
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_suggestions() {

        // Load suggestions
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Suggestions)->load_suggestions();

    }

    /**
     * The public method suggestions_groups gets suggestions groups
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function suggestions_groups() {

        // Gets Groups
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Groups)->suggestions_groups();

    }

    /**
     * The public method delete_group deletes suggestions groups
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function delete_group() {

        // Deletes Groups
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Groups)->delete_group();

    }    

    /**
     * The public method create_category creates a category
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function create_category() {

        // Creates a category
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Categories)->create_category();

    }

    /**
     * The public method get_categories_by_page gets categories by page
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function get_categories_by_page() {

        // Gets categories
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Categories)->get_categories_by_page();

    }

    /**
     * The public method get_all_categories gets all categories
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function get_all_categories() {

        // Gets all categories
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Categories)->get_all_categories();

    }    

    /**
     * The public method delete_category deletes a category
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function delete_category() {

        // Deletes a category
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Categories)->delete_category();

    }

    /**
     * The public method save_message saves message
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function save_message() {

        // Save message
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->save_message();

    }

    /**
     * The public method update_message updates a message
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function update_message() {

        // Update message
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->update_message();

    }

    /**
     * The public method load_messages loads messages
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_messages() {

        // Loads messages
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->load_messages();

    }

    /**
     * The public method check_for_messages verifies if user has messages
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function check_for_messages() {

        // Verifies if user has messages
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->check_for_messages();

    }

    /**
     * The public method delete_messages deletes messages
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function delete_messages() {

        // Delete messages
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->delete_messages();

    }

    /**
     * The public method messages_by_popularity loads messages by popularity
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function messages_by_popularity() {

        // Load messages by popularity
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->messages_by_popularity();

    }

    /**
     * The public method messages_for_graph returns messages for graph
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function messages_for_graph() {

        // Load messages for graph
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->messages_for_graph();

    }

    /**
     * The public method dashboard_messages_for_graph returns messages for graph
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function dashboard_messages_for_graph() {

        // Load messages for graph
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->dashboard_messages_for_graph();

    }

    /**
     * The public method message_activity_graph returns the message's activity for the graph
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function message_activity_graph() {

        // Load activity for message
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Messages)->message_activity_graph();

    }

    /**
     * The public method save_moderation_keywords saves moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function save_moderation_keywords() {

        // Save moderation keywords
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Keywords)->save_moderation_keywords();

    }

    /**
     * The public method update_moderation_keywords udates a moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function update_moderation_keywords() {

        // Update moderation keywords
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Keywords)->update_moderation_keywords();

    }

    /**
     * The public method delete_moderation_keywords deletes moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function delete_moderation_keywords() {

        // Delete moderation keywords
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Keywords)->delete_moderation_keywords();

    }

    /**
     * The public method load_keywords loads keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_keywords() {

        // Loads keywords
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Keywords)->load_keywords();

    }

    /**
     * The public method check_for_moderation_keywords verifies if user has moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function check_for_moderation_keywords() {

        // Verifies if user has moderation keywords
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Keywords)->check_for_moderation_keywords();

    }

    /**
     * The public method load_moderated_comments loads moderated comments
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_moderated_comments() {

        // Loads moderated comments
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Keywords)->load_moderated_comments();

    }

    /**
     * The public method load_all_connected_pages search for connected pages(could return all)
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_all_connected_pages() {

        // Search for pages
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->load_all_connected_pages();

    }

    /**
     * The public method load_connected_pages search for connected pages and return by page
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_connected_pages() {

        // Search for pages
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->load_connected_pages();

    }

    /**
     * The public method connect_facebook_page tries to connect a Facebook Page to be configured
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function connect_facebook_page() {

        // Connect a Facebook Page
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->connect_facebook_page();

    }

    /**
     * The public method account_manager_delete_accounts deletes a Facebook Page
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function account_manager_delete_accounts() {

        // Deletes Facebook Page
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->account_manager_delete_accounts();

    }

    /**
     * The public method save_page_configuration saves a Facebook Page configuration
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function save_page_configuration() {

        // Save Facebook Page configuration
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->save_page_configuration();

    }

    /**
     * The public method connect_to_bot connects Facebook Page to bot
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function connect_to_bot() {

        // Connects Facebook Page to bot
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->connect_to_bot();

    }

    /**
     * The public method disconnect_from_bot disconnects Facebook Page from bot
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function disconnect_from_bot() {

        // Disconnects Facebook Page from bot
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->disconnect_from_bot();

    }

    /**
     * The public method select_facebook_page_category select a Facebook Page category
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function select_facebook_page_category() {

        // Selects Facebook Page category
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Pages)->select_facebook_page_category();

    }

    /**
     * The public method upload_csv uploads a CSV file
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function upload_csv() {

        // Uploads a CSV file
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Csv)->upload_csv();

    }

    /**
     * The public method upload_keywords_from_csv uploads a CSV file with moderation keywords
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function upload_keywords_from_csv() {

        // Uploads a CSV file with moderation keywords
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Csv)->upload_keywords_from_csv();

    }

    /**
     * The public method export_csv exports messages in a CSV file
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function export_csv() {

        // Download messages
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Csv)->export_csv();

    }

    /**
     * The public method export_moderation_keywords exports moderation keywords in a CSV file
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function export_moderation_keywords() {

        // Download moderation keywords
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Csv)->export_moderation_keywords();

    }    

    /**
     * The public method load_subscribers gets subscribers
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_subscribers() {

        // Load subscribers
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Subscribers)->load_subscribers();

    }

    /**
     * The public method load_message_subscribers gets subscribers for a message
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_message_subscribers() {

        // Load subscribers for a message
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Subscribers)->load_message_subscribers();

    }    

    /**
     * The public method get_all_subscriber_categories gets subscriber's categories
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function get_all_subscriber_categories() {

        // Load categories
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Subscribers)->get_all_subscriber_categories();

    }

    /**
     * The public method select_subscriber_category selects subscriber's categories
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function select_subscriber_category() {

        // Select or unselect a category
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Subscribers)->select_subscriber_category();

    }

    /**
     * The public method get_all_subscriber_messages gets the subscriber's messages
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function get_all_subscriber_messages() {

        // Gets messages
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Subscribers)->get_all_subscriber_messages();

    }

    /**
     * The public method save_subscriber_categories adds or removes categories for to subscriber
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function save_subscriber_categories() {

        // Removes or adds categories
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Subscribers)->save_subscriber_categories();

    }

    /**
     * The public method load_history loads the commenter's history
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_history() {

        // Loads conversations
        (new MidrubBaseUserAppsCollectionCommenterHelpers\History)->load_history();

    }

    /**
     * The public method load_phone_numbers loads phone numbers
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_phone_numbers() {

        // Loads phone numbers
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Phone_numbers)->load_phone_numbers();

    }

    /**
     * The public method delete_phone_numbers deletes phone numbers
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function delete_phone_numbers() {

        // Deletes phone numbers
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Phone_numbers)->delete_phone_numbers();

    }

    /**
     * The public method check_for_phone_numbers verifies if user has phone numbers
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function check_for_phone_numbers() {

        // Verifies if user has phone numbers
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Phone_numbers)->check_for_phone_numbers();

    }

    /**
     * The public method export_phone_csv downloads phone numbers
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function export_phone_csv() {

        // Download phone numbers
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Csv)->export_phone_csv();

    }

    /**
     * The public method load_email_addresses loads email addresses
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function load_email_addresses() {

        // Loads email addresses
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Email_addresses)->load_email_addresses();

    }

    /**
     * The public method delete_email_addresses deletes email addresses
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function delete_email_addresses() {

        // Deletes email addresses
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Email_addresses)->delete_email_addresses();

    }

    /**
     * The public method check_for_email_addresses verifies if user has email addresses
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function check_for_email_addresses() {

        // Verifies if user has email addresses
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Email_addresses)->check_for_email_addresses();

    }

    /**
     * The public method export_email_csv downloads email addresses
     * 
     * @since 0.0.8.1
     * 
     * @return void
     */
    public function export_email_csv() {

        // Download email addresses
        (new MidrubBaseUserAppsCollectionCommenterHelpers\Csv)->export_email_csv();

    }


}

/* End of file ajax.php */