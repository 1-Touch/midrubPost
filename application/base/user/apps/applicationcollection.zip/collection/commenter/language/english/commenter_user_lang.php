<?php
$lang["commenter"] = "Commenter";
$lang["create_category"] = "Create Category";
$lang["save"] = "Save";
$lang["enter_category_name"] = "Enter the category's name";
$lang["please_enter_valid_category"] = "Please enter the category's name.";
$lang["category_was_saved"] = "Category was saved successfully.";
$lang["category_was_not_saved"] = "Category wasn't saved successfully.";
$lang["no_categories_found"] = "No categories found.";
$lang["no_category_found"] = "No category found.";
$lang["category_was_deleted"] = "The category was deleted successfully.";
$lang["category_was_not_deleted"] = "The category wasn't deleted successfully.";
$lang["no_groups_found"] = "No suggestions groups found.";
$lang["no_suggestions_found"] = "No suggestions found.";
$lang["group_was_deleted"] = "The group was deleted successfully.";
$lang["group_was_not_deleted"] = "The group wasn't deleted successfully.";
$lang["group_was_saved"] = "The group was saved successfully.";
$lang["group_was_not_saved"] = "The group wasn't saved successfully.";
$lang["commenter_enter_name_suggestions_group"] = "Enter the name of suggestions group ...";
$lang["commenter_uncategorized"] = "Uncategorized";
$lang["commenter_manage_categories"] = "Manage Categories";
$lang["commenter_search_categories"] = "Search for categories ...";
$lang["commenter_start_conversation"] = "Start Conversation";
$lang["commenter_private_messages"] = "Private Messages";
$lang["commenter_messages_stats"] = "Messages Stats";
$lang["commenter_search_messages"] = "Search for messages ...";
$lang["commenter_search_moderation_keywords"] = "Search for moderation keywords ...";
$lang["commenter_new_message"] = "New Message";
$lang["commenter_import_csv"] = "Import CSV";
$lang["commenter_export_csv"] = "Export CSV";
$lang["commenter_create_new_message"] = "Create New Message";
$lang["commenter_new_keywords_list"] = "Add Moderation Keywords";
$lang["commenter_enter_the_keywords"] = "Enter the keywords which should be in a question without any special tags ...";
$lang["commenter_enter_the_moderation_keywords"] = "Enter the keywords which should be in a comment without any special tags ...";
$lang["commenter_keywords"] = "Keywords";
$lang["commenter_text_message"] = "Text Message";
$lang["commenter_suggestions"] = "Suggestions Groups";
$lang["commenter_select_suggestion"] = "Select a suggestions group";
$lang["commenter_search_suggestions"] = "Search for suggestions groups ...";
$lang["commenter_text_message_or_suggestions"] = "If you're adding a text message, will be used the text as message. If you're selecting a suggestions group will be used the suggestions group as message.";
$lang["commenter_please_enter_text_message"] = "Please enter a text message.";
$lang["commenter_please_select_suggestion_group"] = "Please select a suggestion group.";
$lang["commenter_error_occurred"] = "An error occurred while processing your request.";
$lang["commenter_message_was_not_saved"] = "The message wasn't saved successfully.";
$lang["commenter_keywords_too_short"] = "Please enter at least one keyword.";
$lang["commenter_message_was_saved"] = "The message was saved successfully.";
$lang["commenter_message_was_saved_without_response"] = "The message was saved successfully but without response.";
$lang["commenter_no_messages_found"] = "No messages found.";
$lang["commenter_no_keywords_found"] = "No keywords found.";
$lang["commenter_no_comments_found"] = "No comments found.";
$lang["commenter_response"] = "Response";
$lang["commenter_active_last_month"] = "Messages in the last 30 days";
$lang["commenter_please_select_at_least_message"] = "Please select at least a message.";
$lang["commenter_messages_were_deleted"] = " messages were deleted successfully.";
$lang["commenter_new_suggestions_group"] = "New Suggestions Group";
$lang["commenter_welcome"] = "Welcome";
$lang["commenter_subscribers"] = "Subscribers";
$lang["commenter_history"] = "History";
$lang["commenter_audit_logs"] = "Audit Logs";
$lang["commenter_facebook_pages"] = "Facebook Pages";
$lang["commenter_search_facebook_pages"] = "Search for facebook pages ...";
$lang["commenter_setting_greeting"] = "Setting the Greeting Text or Suggestions";
$lang["commenter_default_response"] = "Default Response";
$lang["commenter_if_no_response"] = "If you enter a response here, people will see it when you don't have a message for them in the database.";
$lang["commenter_enter_default_response"] = "Enter the response which will be displayed if no message found ...";
$lang["commenter_facebook_categories"] = "Facebook Page Categories";
$lang["commenter_search_subscribers"] = "Search for subscribers ...";
$lang["commenter_messages"] = "Messages";
$lang["commenter_categories"] = "Categories";
$lang["commenter_last_conversations"] = "Last conversations";
$lang["commenter_connect_pages"] = "Facebook Pages Manager";
$lang["commenter_instructions"] = "Instructions";
$lang["commenter_connect_pages_btn"] = "Connect Pages";
$lang["commenter_connect_instructions"] = "<ul class=\"instructions\">"
                                            . "<li>"
                                                . "<h4><i class=\"icon-info\"></i> Click on the button Connect Pages.</h4>"
                                            . "</li>"
                                            . "<li>"
                                                . "<h4><i class=\"icon-info\"></i> Select which Facebook Pages you want to connect.</h4>"
                                            . "</li>"
                                            . "<li>"
                                                . "<h4><i class=\"icon-info\"></i> Allow to our app to publish in your Facebook Pages and manage your conversations.</h4>"
                                            . "</li>"
                                            . "<li>"
                                                . "<h4><i class=\"icon-info\"></i> Will be connected all your Facebook Pages.</h4>"
                                            . "</li>"
                                            . "<li>"
                                                . "<h4><i class=\"icon-info\"></i> Next, subscribe the page to our bot and select categories for your Facebook Page.</h4>"
                                            . "</li>"
                                        . "</ul>";
$lang["commenter_no_pages_found"] = "No Facebook Pages found.";
$lang["commenter_connect"] = "Connect";
$lang["commenter_connect_to_bot"] = "Connect Facebook Page to Bot";
$lang["commenter_connect_to_bot_instructions"] = "To be able to automatize messages on your Facebook Page messenger you have to connect your Facebook Page to our Bot.";
$lang["commenter_connect_to_bot_btn"] = "Connect to Bot";
$lang["commenter_disconnect_from_bot_btn"] = "Disconnect from Bot";
$lang["commenter_enable"] = "Enable";
$lang["commenter_you_have_unsaved_changes"] = "You have unsaved changes.";
$lang["commenter_save_changes"] = "Save Changes";
$lang["commenter_facebook_categories"] = "Instead to add private messages to any Facebook Page, you can select categories from which private messages will be displayed.";
$lang["commenter_connect_facebook_page"] = "Connect Facebook Page";
$lang["commenter_connect_facebook_page_instructions"] = "In the Facebook Pages list, please click on the Connect button to be able to configure your Facebook Page. If you're seeing no page found message, please click on the button <i class=\"icon-user-follow\"></i> and connect your Facebook Pages and then click on the button Connect.";
$lang["commenter_page_not_found"] = "Facebook Page not found.";
$lang["commenter_you_are_not_owner"] = "Seems you are not the owner of the Facebook Page.";
$lang["commenter_invalid_access_token"] = "The page's access token is not valid. Please reconnect the Facebook Page.";
$lang["commenter_changes_saved_successfully"] = "The changes were saved successfully.";
$lang["commenter_changes_not_saved_successfully"] = "The changes were not saved successfully.";
$lang["commenter_changes_saved_successfully_but_error_occurred"] = "Almost all changes were saved successfully. Please re-connect to see which weren't saved.";
$lang["commenter_menu"] = "Menu";
$lang["commenter_select_suggestions_group"] = "Select a suggestion group which will be used as menu in the messenger.";
$lang["commenter_page_was_subscribed"] = "The page was subscribed successfully to the bot.";
$lang["commenter_page_was_not_subscribed"] = "The page was not subscribed successfully to the bot.";
$lang["commenter_page_was_unsubscribed"] = "The page was unsubscribed successfully to the bot.";
$lang["commenter_page_was_not_unsubscribed"] = "The page was not unsubscribed successfully to the bot.";
$lang["commenter_page_or_category_wrong"] = "The page or category is wrong.";
$lang["commenter_you_are_not_owner_category"] = "Seems you are not the owner of the category.";
$lang["commenter_accuracy"] = "Accuracy";
$lang["commenter_enter_category_name"] = "Enter the category name ...";
$lang["commenter_new_category"] = "New Category";
$lang["commenter_all_categories"] = "All Categories";
$lang["commenter_message_id_missing"] = "The Message ID missing.";
$lang["commenter_message_was_updated_successfully"] = "The message was updated successfully.";
$lang["commenter_message_was_not_updated_successfully"] = "The message was not updated successfully.";
$lang["commenter_message_was_updated_successfully_without_response"] = "The message was updated successfully but the message's response wasn't saved.";
$lang["commenter_message_was_updated_successfully_without_categories"] = "The message was updated successfully but some categories weren't saved.";
$lang["commenter_delete"] = "Delete";
$lang["commenter_drop_csv_here"] = "Drop CSV here or click to upload.";
$lang["commenter_upload"] = "Upload";
$lang["commenter_select_csv"] = "Select CSV File";
$lang["commenter_import_csv_instructions"] = "Click on the button below to upload a CSV file with messages. Please respect the format, otherwise the file won't be uploaded.";
$lang["commenter_file_too_large"] = "The CSV file is too large.";
$lang["commenter_messages_imported"] = " messages were imported successfully.";
$lang["commenter_download"] = "Download";
$lang["commenter_download_csv"] = "Download all messages";
$lang["commenter_export_csv_instructions"] = "By clicking on the button below you will export all messages in a CSV file. You can after import them, but will be added to existing, not replacing.";
$lang["commenter_search_subscribers"] = "Search for subscribers ...";
$lang["commenter_no_subscribers_found"] = "No subscribers found.";
$lang["commenter_details"] = "Details";
$lang["commenter_message_message"] = "Message and Bot's Message";
$lang["commenter_no_valid_subscriber"] = "The subscriber not exists.";
$lang["commenter_subscriber_or_category_wrong"] = "The subscriber or category is wrong.";
$lang["commenter_no_messages_found"] = "No messages found.";
$lang["commenter_no_conversations_found"] = "No conversations found.";
$lang["commenter_search_conversations"] = "Search for conversations ...";
$lang["commenter_conversation"] = "Conversation";
$lang["commenter_conversations"] = "Conversations";
$lang["commenter_total_messages"] = "Total messages";
$lang["commenter_quick_messages_popularity"] = "Private messages by Popularity";
$lang["commenter_replied"] = "# sent";
$lang["commenter_all_facebook_pages"] = "All Facebook Pages";
$lang["commenter_group_deleted"] = "the suggestions group was deleted";
$lang["commenter_error"] = "Occurred error";
$lang["commenter_categories_manager"] = "Categories Manager";
$lang["commenter_suggestions_manager"] = "Suggestions Manager";
$lang["commenter_category"] = "Category";
$lang["commenter_generic_template"] = "Generic Template";
$lang["commenter_media_template"] = "Media Template";
$lang["commenter_button_template"] = "Button Template";
$lang["commenter_list_template"] = "List Template";
$lang["commenter_template"] = "Template";
$lang["commenter_header"] = "Header";
$lang["commenter_drag_image_click_to_upload"] = "Drop image here or click to upload.";
$lang["commenter_enter_template_title"] = "Enter the template's title ...";
$lang["commenter_enter_template_subtitle"] = "Enter the template's subtitle ...";
$lang["commenter_enter_main_url"] = "Enter the main url ...";
$lang["commenter_button_1"] = "Button 1 (Required)";
$lang["commenter_link"] = "Link";
$lang["commenter_suggestions"] = "Suggestions";
$lang["commenter_enter_button_title"] = "Enter the button's title ...";
$lang["commenter_enter_button_url"] = "Enter the button's url ...";
$lang["commenter_button_2"] = "Button 2 (Optional)";
$lang["commenter_button_3"] = "Button 3 (Optional)";
$lang["commenter_all_suggestions_group"] = "All Suggestions Groups";
$lang["commenter_search_for_groups"] = "Search for groups ...";
$lang["commenter_number_bot_messages"] = "# of bot messages";
$lang["commenter_no_suggestions_found"] = "No suggestions found.";
$lang["commenter_image_can_not_be_uploaded"] = "The image can't be uploaded on Facebook.";
$lang["commenter_template_title_required"] = "The template\'s title is required.";
$lang["commenter_template_subtitle_required"] = "The template\'s subtitle is required.";
$lang["commenter_template_url_required"] = "The template\'s url is required.";
$lang["commenter_template_requires_at_least_one_button"] = "The template requires at least one button.";
$lang["commenter_please_enter_correct_data_for_your_button"] = "Please enter correct data in all used buttons.";
$lang["commenter_please_consigure_buttons_correct_order"] = "Please configure buttons in correct order.";
$lang["commenter_templates_supports_only_images"] = "Templates supports only images.";
$lang["commenter_please_upload_an_image"] = "Please upload an image.";
$lang["commenter_reached_maximum_number_bot_messages"] = "You've reached the maximum number of Bot's messages for your plan.";
$lang["commenter_our_plans"] = "Our Plans";
$lang["commenter_facebook_page_was_deleted"] = "The Facebook Page was deleted successfully.";
$lang["commenter_facebook_page_was_not_deleted"] = "The Facebook Page was not deleted successfully.";
$lang["commenter_moderate_comments"] = "Moderate Comments";
$lang["commenter_new_keywords"] = "New Keywords";
$lang["commenter_actions"] = "Actions";
$lang["commenter_actions_delete"] = "The comments which will have the keywords above will be hidden automatically. You can control the accuracy from the keywords page.";
$lang["commenter_moderation_keywords_were_saved"] = "The moderation keywords were saved successfully.";
$lang["commenter_moderation_keywords_were_not_saved"] = "The moderation keywords were not saved successfully.";
$lang["commenter_please_select_at_least_moderation_keyword"] = "Please select at least a moderation keyword.";
$lang["commenter_moderation_keywords_were_delete"] = " moderation keywords were deleted successfully.";
$lang["commenter_moderation_keywords_were_not_delete"] = " moderation keywords were not deleted successfully.";
$lang["commenter_moderation_keywords_were_imported"] = " moderation keywords were imported successfully.";
$lang["commenter_import_keywords_csv_instructions"] = "Click on the button below to upload a CSV file with moderation keywords. Please respect the format, otherwise the file won't be uploaded.";
$lang["commenter_keywords_imported"] = " moderation keywords were imported successfully.";
$lang["commenter_download_keywords_csv"] = "Download all keywords";
$lang["commenter_export_keywords_csv_instructions"] = "By clicking on the button below you will export all moderation keywords in a CSV file. You can after import them, but will be added to existing, not replacing.";
$lang["commenter_keywords_was_updated_successfully"] = "The moderation keywords were updated successfully.";
$lang["commenter_keywords_was_not_updated_successfully"] = "The moderation keywords were not updated successfully.";
$lang["commenter_keywords_id_missing"] = "The moderation keywords ID is not valid.";
$lang["commenter_hidden_comments"] = "Hidden Comments";
$lang["commenter_message_reply"] = "Message and Bot's Reply";
$lang["commenter_error_occurred_no_categories_deleted"] = "An error occurred and some categories were not unselected.";
$lang["commenter_changes_were_saved"] = "The changes were saved successfully.";
$lang["commenter_changes_were_not_saved"] = "The changes were not saved successfully.";
$lang["commenter_phone_numbers"] = "Phone Numbers";
$lang["commenter_email_addresses"] = "Email Addresses";
$lang["commenter_search_phone_numbers"] = "Search for phone numbers ...";
$lang["commenter_search_email_addresses"] = "Search for email addresses ...";
$lang["commenter_no_phone_numbers_found"] = "No phone numbers found.";
$lang["commenter_phone_numbers_were_deleted"] = " phone numbers were deleted successfully.";
$lang["commenter_you_have_a_new_phone_number"] = "You have new phone numbers catched from one or more messages.";
$lang["commenter_more_details"] = "More Details";
$lang["commenter_no_email_addresses_found"] = "No email addresses found.";
$lang["commenter_email_addresses_were_deleted"] = " email addresses were deleted successfully.";
$lang["commenter_you_have_a_new_email_addresses"] = "You have new email addresses catched from one or more messages.";