<?php
$lang["commenter"] = "Facebook Commenter";
$lang["commenter_allow"] = "Allow Facebook Commenter";
$lang["commenter_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Facebook Commenter.";