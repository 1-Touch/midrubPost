<?php
$lang["commenter_replies_stats"] = "Bot Replies Stats";