<?php
$lang["commenter"] = "Commenter";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled_commenter"] = "You will be able to see it in the Plans page";
$lang["if_is_enabled_commenter_plan"] = "If is enabled the commenter app will be available for this plan";
$lang["app_token"] = "App Token";
$lang["app_token_description"] = "Invent an App Token which you will use here and in Facebook Webhooks.";
$lang["number_allowed_replies"] = "Bot Replies";
$lang["number_allowed_replies_description"] = "Enter the number of bot's replies per month.";
