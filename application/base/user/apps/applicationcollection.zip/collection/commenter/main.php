<?php
/**
 * Midrub Apps Commenter
 *
 * This file loads the Commenter app
 *
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
 */

// Define the page namespace
namespace MidrubBase\User\Apps\Collection\Commenter;

// Define the constants
defined('BASEPATH') OR exit('No direct script access allowed');
defined('MIDRUB_BASE_USER_APPS_COMMENTER') OR define('MIDRUB_BASE_USER_APPS_COMMENTER', MIDRUB_BASE_USER . 'apps/collection/commenter/');
defined('MIDRUB_BASE_USER_APPS_COMMENTER_VERSION') OR define('MIDRUB_BASE_USER_APPS_COMMENTER_VERSION', '0.0.3');
defined('MIDRUB_COMMENTER_FACEBOOK_GRAPH_URL') OR define('MIDRUB_COMMENTER_FACEBOOK_GRAPH_URL', 'https://graph.facebook.com/v5.0/');

// Define the namespaces to use
use MidrubBase\User\Interfaces as MidrubBaseUserInterfaces;
use MidrubBase\User\Apps\Collection\Commenter\Controllers as MidrubBaseUserAppsCollectionCommenterControllers;

/*
 * Main class loads the Commenter app loader
 * 
 * @author Scrisoft
 * @package Midrub
 * @since 0.0.8.0
 */
class Main implements MidrubBaseUserInterfaces\Apps {
    
    /**
     * Class variables
     *
     * @since 0.0.8.0
     */
    protected
            $CI;

    /**
     * Initialise the Class
     *
     * @since 0.0.8.0
     */
    public function __construct() {
        
        // Assign the CodeIgniter super-object
        $this->CI =& get_instance();
        
    }

    /**
     * The public method check_availability checks if the app is available
     *
     * @return boolean true or false
     */
    public function check_availability() {

        if ( !get_option('app_commenter_enable') || !plan_feature('app_commenter') || !team_role_permission('commenter') ) {
            return false;
        } else {
            return true;
        }
        
    }
    
    /**
     * The public method user loads the app's main page in the user panel
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function user() {
        
        // Verify if the app is enabled
        if ( !get_option('app_commenter_enable') || !plan_feature('app_commenter') || !team_role_permission('commenter') ) {
            show_404();
        }
        
        // Instantiate the class
        (new MidrubBaseUserAppsCollectionCommenterControllers\User)->view();
        
    }    

    /**
     * The public method ajax processes the ajax's requests
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function ajax() {
        
        // Verify if the app is enabled
        if ( !get_option('app_commenter_enable') || !plan_feature('app_commenter') || !team_role_permission('commenter') ) {
            exit();
        }        
        
        // Get action's get input
        $action = $this->CI->input->get('action');

        if ( !$action ) {
            $action = $this->CI->input->post('action');
        }
        
        try {
            
            // Call method if exists
            (new MidrubBaseUserAppsCollectionCommenterControllers\Ajax)->$action();
            
        } catch (Exception $ex) {
            
            $data = array(
                'success' => FALSE,
                'message' => $ex->getMessage()
            );
            
            echo json_encode($data);
            
        }
        
    }

    /**
     * The public method rest processes the rest's requests
     * 
     * @param string $endpoint contains the requested endpoint
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function rest($endpoint) {

    }
    
    /**
     * The public method cron_jobs loads the cron jobs commands
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function cron_jobs() {
        
    }
    
    /**
     * The public method delete_account is called when user's account is deleted
     * 
     * @param integer $user_id contains the user's ID
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function delete_account($user_id) {
        
        // Require the User Inc
        require_once MIDRUB_BASE_USER_APPS_COMMENTER . 'inc/user.php';

        // Delete all user's records in this app
        delete_user_from_facebook_commenter($user_id);

    }

    /**
     * The public method hooks contains the app's hooks
     * 
     * @param string $category contains the hooks category
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function load_hooks( $category ) {

        // Load and run hooks based on category
        switch ( $category ) {

            case 'admin_init':

                // Load the admin app's language files
                $this->CI->lang->load('commenter_admin', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_COMMENTER);

                // Verify which component is
                if ( ( md_the_component_variable('component') === 'user' ) && ( $this->CI->input->get('app', TRUE) === 'commenter' ) ) {

                    // Require the Admin Inc
                    md_include_component_file(MIDRUB_BASE_USER_APPS_COMMENTER . 'inc/admin.php');

                } else if ( ( md_the_component_variable('component') === 'user' ) && ( md_the_component_variable('component_display') === 'plans' ) ) {

                    // Require the Plans Inc
                    md_include_component_file(MIDRUB_BASE_USER_APPS_COMMENTER . 'inc/plans.php');

                }

                break;

            case 'user_init':

                // Verify which component is
                if ( md_the_component_variable('component') === 'team' ) {

                    if ( get_option('app_commenter_enable') && plan_feature('app_commenter') ) {

                        // Load the app's language files
                        $this->CI->lang->load('commenter_member', $this->CI->config->item('language'), FALSE, TRUE, MIDRUB_BASE_USER_APPS_COMMENTER);

                        // Require the Permissions Inc
                        md_include_component_file(MIDRUB_BASE_USER_APPS_COMMENTER . 'inc/members.php');

                    }

                }

                break;

        }

        // Require the General Inc
        get_the_file(MIDRUB_BASE_USER_APPS_COMMENTER . 'inc/general.php');

    }

    /**
     * The public method guest contains the app's access for guests
     * 
     * @since 0.0.8.0
     * 
     * @return void
     */
    public function guest() {

        // Verify if is a bot verification
        if ( $this->CI->input->get('hub_challenge', TRUE) && $this->CI->input->get('hub_verify_token', TRUE) ) {
            
            // Verify if the token is correct
            if ( $this->CI->input->get('hub_verify_token', TRUE) === get_option('app_facebook_commenter_verify_token') ) {

                // Display hub's challenge
                echo $this->CI->input->get('hub_challenge', TRUE);

            }
            
        } else {

            // Decode the Facebook Request
            $input = $this->CI->security->xss_clean(json_decode(file_get_contents('php://input'), true));

            // Verify if Facebook Page Id exists
            if (isset($input['entry'][0]['changes'][0]['field'])) {

                // Process the request
                (new MidrubBaseUserAppsCollectionCommenterControllers\Bot)->process($input);
                
            }

        }

    }
    
    /**
     * The public method app_info contains the app's info
     * 
     * @since 0.0.8.0
     * 
     * @return array with app's information
     */
    public function app_info() {
        
        // Return app information
        return array(
            'app_name' => $this->CI->lang->line('commenter'),
            'app_slug' => 'commenter',
            'app_icon' => '<i class="icon-bubble"></i>',
            'version' => MIDRUB_BASE_USER_APPS_COMMENTER_VERSION,
            'min_version' => '0.0.8.0',
            'max_version' => '0.0.8.1',
        );
        
    }

}

/* End of file main.php */